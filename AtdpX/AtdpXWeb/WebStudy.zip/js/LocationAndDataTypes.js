﻿/**
 * Created by WangJun on 2016/2/19.
 */



function autoAdd(){
    var dataTypeInt=1
    while(dataTypeInt<11)
    {
        dataTypeInt++
    }
    alert("dataTypeInt值自增11次,当前值："+dataTypeInt)
}
function outPutString(){
    var dataTypeString="beijing";
    alert(dataTypeString)
}
function dataTypeBooleen() {
    var dataTypeBooleen=false;
    if (dataTypeBooleen)
    {
        dataTypeBooleen=false
    }
    else
    {
        dataTypeBooleen=true

    }
    array.join()
    Math.
    alert('dataTypeBooleen现在值为：'+dataTypeBooleen)
}
function dataTyprFloat(){
    var dataTyprFloat=1.00;
    alert(dataTyprFloat)
    toF
}
function custom_close(){
    if
    (confirm("您确定要关闭本页吗？")){
        window.opener=null;
        window.open('','_self');
        window.close();
    }
    else{}
}
